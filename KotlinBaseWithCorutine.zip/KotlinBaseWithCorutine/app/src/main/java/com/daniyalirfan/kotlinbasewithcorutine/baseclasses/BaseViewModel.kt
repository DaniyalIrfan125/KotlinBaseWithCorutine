package com.daniyalirfan.kotlinbasewithcorutine.baseclasses

import androidx.lifecycle.ViewModel


open class BaseViewModel : ViewModel() {
}