package com.daniyalirfan.kotlinbasewithcorutine.data.local.db

import androidx.room.Dao

@Dao
interface AppDao {


}