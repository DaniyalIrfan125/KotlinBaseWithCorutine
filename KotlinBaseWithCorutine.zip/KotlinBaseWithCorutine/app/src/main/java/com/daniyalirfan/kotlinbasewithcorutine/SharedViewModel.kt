package com.daniyalirfan.kotlinbasewithcorutine

import com.daniyalirfan.kotlinbasewithcorutine.baseclasses.BaseViewModel


/**
 * Shared View Model class for sharing data between fragments
 */
class SharedViewModel : BaseViewModel() {

}