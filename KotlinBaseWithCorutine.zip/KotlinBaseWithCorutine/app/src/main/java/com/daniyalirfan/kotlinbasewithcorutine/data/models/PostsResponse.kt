package com.daniyalirfan.kotlinbasewithcorutine.data.models

class PostsResponse : ArrayList<PostsResponseItem>()


